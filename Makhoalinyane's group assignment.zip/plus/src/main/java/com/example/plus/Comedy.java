package com.example.plus;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Comedy {
    @FXML
    void a(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=fRAwvGd_8cE");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void b(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=uDA0CzGzjsA");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void c(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=KBmoI2dm2kg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void d(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=sAN-nLu9Ssg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void e(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=VYOjWnS4cMY");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    void f(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=VexynUlEcUg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }
    @FXML
    void g(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=-oalik58TWg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void h(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=lyq_G3oQUf8");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    void eight(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=lyq_G3oQUf8");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void five(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=VYOjWnS4cMY");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void four(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=sAN-nLu9Ssg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void one(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=fRAwvGd_8cE");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void seven(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=-oalik58TWg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void six(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=VexynUlEcUg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void three(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=KBmoI2dm2kg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void two(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=uDA0CzGzjsA");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }
}
