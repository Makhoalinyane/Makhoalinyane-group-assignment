package com.example.plus;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

public class HelloController {
    @FXML
    private ImageView bc,ec,gl,hs,mlw,page,rn,rs;

    WebView view = new WebView();
    @FXML
    void a(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=tJ-qvbpvuQY");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void b(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=bWMAWea2zRw");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void c(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=ZgAuq4sxTbE");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void d(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=2JZlFgVVreU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();



    }

    @FXML
    void e(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=2TaaaiFRT60");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }
    @FXML
    void f(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=_5EkSF8-8o0");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void g(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=mX1mZCvws1M");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    void h(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=Esp1Fm-jMOM");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML

    void BC(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=bWMAWea2zRw");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void HS(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=tJ-qvbpvuQY");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    void gl(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=_5EkSF8-8o0");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void mlw(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=ZgAuq4sxTbE");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void page(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=2TaaaiFRT60");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void rn(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=2JZlFgVVreU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void rs(MouseEvent event) {
        view.getEngine().load("https://www.youtube.com/watch?v=mX1mZCvws1M");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    public void ec(MouseEvent mouseEvent) {
        view.getEngine().load("https://www.youtube.com/watch?v=Esp1Fm-jMOM");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}