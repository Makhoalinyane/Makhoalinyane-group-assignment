package com.example.plus;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;


public class Romance {
    @FXML
    void a(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=5-RZFmZwXc4");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void b(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=Y8aKHTEGkZQ");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void c(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=RfFwthVJAOg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void d(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=PKpoHAdI_JU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void e(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=8276jGH10nU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    void f(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=URTtGqQZrpA");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    void g(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=mAcc-T7eItk");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    void h(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=IZYNrDOzvVU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }
    @FXML
    void eight(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=IZYNrDOzvVU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void five(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=8276jGH10nU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void four(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=PKpoHAdI_JU");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void one(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=5-RZFmZwXc4");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void seven(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=mAcc-T7eItk");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void six(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=URTtGqQZrpA");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void three(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=RfFwthVJAOg");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    @FXML
    void two(MouseEvent event) {
        WebView view = new WebView();
        view.getEngine().load("https://www.youtube.com/watch?v=Y8aKHTEGkZQ");
        VBox vBox =new VBox(view);
        Scene scene=new Scene(vBox, 950,600);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();


    }
}
